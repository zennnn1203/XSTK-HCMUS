install.packages("leaps")
install.packages("stagewise")
library(leaps)
#read_data
setwd("C:/Users/tuanvl/Desktop/ThS/Ex6")
fire=read.csv("fire.csv",header=TRUE)
str(fire)

#All_model
full=regsubsets(Fire~.,data=fire,nvmax=3,nbest=3)
smfull=summary(full)
smfull

#Selection_model
par(mfrow=c(2,2))
plot(smfull$rsq, ylab="R-squared",type = "b", pch = 16)
plot(smfull$adjr2, ylab="R-adj",type = "b", pch = 16)
plot(smfull$cp, ylab="Cp",type = "b", pch = 16)
plot(smfull$bic, ylab="BIC",type = "b", pch = 16)
coef(full,4)
summary(lm(Fire~X_2+X_3,data=fire))
