library(corrplot)
library(leaps)
library(lmtest)
library(factoextra)
library(devtools)
library(ggbiplot)
library(ggplot2)


#read data
dat=read.table("E:/length_baby.csv",header=TRUE, sep = ',')
str(dat)
head(dat)


#missing value
library(VIM)
aggr(dat,sortComb=TRUE, sortVar=TRUE, only.miss=TRUE)

#outliers
outliers <- function(x){
  # 1st and 3rd quantiles
  q75 = quantile(x, 0.75)
  q25 = quantile(x, 0.25)
  IQR = q75-q25
  # lower bound
  lower_bound = q25 - 3 * IQR
  # upper bound
  upper_bound = q75 + 3 * IQR
  # outliers
  outlier_ind <- which(x < lower_bound | x > upper_bound)
  if (length(outlier_ind) == 0){
    return (0)
  }
  return(outlier_ind)
}
par(mfrow=c(1,1))
boxplot(dat)
apply(dat,2,outliers)
dat=dat[-c(26),]

#visualize
par(mfrow=c(1,1))
corrplot::corrplot(cor(dat), method="number")
nrow(dat)
library(car)
car::vif(lm(dat$Length ~ ., data = dat))
#Thong ke mo ta
summary(dat)
pastecs::stat.desc(dat)
unique(dat$Length)
unique(dat$Birthweight)
unique(dat$smoker)
hist(dat$Length,main="Distribution of Length", xlab="Length" ,col="red")
ggplot(dat,aes(Birthweight,Length)) +geom_point()+geom_smooth(method=lm)
ggplot(dat,aes(mheight,Length)) +geom_point()+geom_smooth(method=lm)
ggplot(dat,aes(fnocig,Length)) +geom_point()+geom_smooth(method=lm)
#PCA
dat2=dat[,-c(2)]
pca=prcomp(dat2, scale = TRUE, center = TRUE)
summary(pca)
install.packages('factoextra')
library(factoextra)
fviz_eig(pca)
y=subset(dat,select=c(2))
pca_set=data.frame(y,pca$x[,1:15])
mod_pca=lm(dat$Length~PC1+PC2+PC3+PC4+PC5+PC6+PC7,data=pca_set)
summary(mod_pca)
last_mod = lm(dat$Length~PC1+PC2+PC3,data=pca_set)
summary(last_mod)


par(mfrow=c(2,2))
plot(last_mod)

#independent_check
lag.plot(last_mod$residuals)
car::durbinWatsonTest(last_mod)

#stability_check
lmtest::bptest(last_mod)

#normal_check
shapiro.test(last_mod$residuals)

pca
fviz_pca_var(pca,
             col.var = "contrib",
             gradient.cols = c("#00AFBB", "#E7B800", "#FC4E07"),
             repel = TRUE     # Avoid text overlapping
)
