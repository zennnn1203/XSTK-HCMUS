library(corrplot)
library(car)
library(leaps)
library(lmtest)
library(factoextra)
library(devtools)
library(ggbiplot)
library(VIM)
library(pastecs)
library(gridExtra)
library(ggpubr)
#a) Data_importation
setwd("C:/Users/tuanvl/Desktop/ThS/FinalProject")
diet=read.csv("Diet.csv",header=TRUE)
str(diet)
n=nrow(diet)
head(diet)
dim(diet)
#-------------------------------------------------------------------
#b) Data_cleaning
#b1) Missing_values
aggr(diet[1:7],sortComb=TRUE, sortVar=TRUE, only.miss=TRUE)
diet=diet[-c(1,2),] #Missing percent < 3% so remove them
print(nrow(diet))
duplicated(diet) #duplicated data
#b2) Remove_Outliers
#outliers_function
outliers <- function(x){
  # 1st and 3rd quantiles
  q75 = quantile(x, 0.75)
  q25 = quantile(x, 0.25)
  IQR = q75-q25
  # lower bound
  lower_bound = q25 - 3 * IQR
  # upper bound
  upper_bound = q75 + 3 * IQR
  # outliers
  outlier_ind <- which(x < lower_bound | x > upper_bound)
  if (length(outlier_ind) == 0){
    return (0)
  }
  return(outlier_ind)
}
par(mfrow=c(1,1))
boxplot(diet)
apply(diet,2,outliers) #Check outliers
#-------------------------------------------------------------------
#c) Data_visualization
diet$loss_weight = diet$pre.weight - diet$weight6weeks
loss_weight
stat.desc(diet) #descriptive_statistics
#descriptive_statistics with graph
gg1=ggplot(data = diet) + geom_histogram(aes(x = gender), stat = "count") + labs(x = "gender", y = "count")
gg2=ggplot(data = diet) + geom_histogram(aes(x = Diet), stat = "count") + labs(x = "Diet", y = "count")
require(gridExtra)
grid.arrange(gg1,gg2, ncol=2, nrow=1)
par(mfrow=c(1,3))
plot(density(diet$Age),main="Density of Age",xlab="Age")
plot(density(diet$Height),main="Density of Height",xlab="Height")
plot(density(diet$pre.weight),main="Density of pre.weight",xlab="pre.Weight")
par(mfrow=c(1,2))
means1 <- aggregate(loss_weight ~  Diet, data=diet, mean)
boxplot(loss_weight ~ Diet, data=diet)
points(1:3, means1$loss_weight,col = "red", pch=18)

means2 <- aggregate(loss_weight ~  gender, data=diet, mean)
boxplot(loss_weight ~ gender, data=diet)
points(1:3, means1$loss_weight,col = "red", pch=18)
#-------------------------------------------------------------------
#d) ANOVA1WAY
Diet=factor(diet$Diet)
loss_weight=diet$loss_weight
av1 = aov(loss_weight~Diet)
#normality assumption
par(mfrow=c(1,1))
ggqqplot(av1$residuals)
shapiro.test(av1$residuals) 
#Each group size is small
#tapply(loss_weight,Diet,shapiro.test) each group size is big
#Homogneity of variance
plot(av1,1)
leveneTest(loss_weight~Diet)
#computation
summary(av1)
TukeyHSD(av1)
plot(TukeyHSD(av1),las=1)
#--------------------------------------------------------------------
#e) ANOVA2
gender=factor(diet$gender)
av2=aov(loss_weight~gender*Diet)
av2_res=av2$residuals

#computation
summary(av2)
summary(aov(loss_weight~gender+Diet))
summary(aov(loss_weight~gender))
summary(aov(loss_weight~Diet))
summary(aov(loss_weight~1))
TukeyHSD(av2)
plot(TukeyHSD(av2),las=1)

#normality assumption
ggqqplot(av2_res)
shapiro.test(av2_res)
#Homogneity of variance
plot(av2,1)
leveneTest(loss_weight~gender*Diet)