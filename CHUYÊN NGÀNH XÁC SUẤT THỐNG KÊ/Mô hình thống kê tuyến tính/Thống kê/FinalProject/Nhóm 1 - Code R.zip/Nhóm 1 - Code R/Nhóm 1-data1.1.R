data = read.csv('E:/Downloads/auto_mpg.csv', sep = ';')
library(pastecs)
library(knitr)
library(dplyr)
library(corrplot)
library(ggplot2)
#Lam sach va thuc hien thong ke mo ta
colnames(data)[colnames(data) == 'mgp'] <- 'mpg'
str(data)
head(data)
unique(data$horsepower)
data$horsepower[data$horsepower == '?'] <- NA
sum(is.na(data$horsepower))
#Lam sach du lieu
data$horsepower = as.numeric(data$horsepower)
data$horsepower[is.na(data$horsepower)] = mean(data$horsepower,na.rm = T)
#Loai bo outliers:
#outliers
outliers <- function(x){
  # 1st and 3rd quantiles
  q75 = quantile(x, 0.75)
  q25 = quantile(x, 0.25)
  IQR = q75-q25
  # lower bound
  lower_bound = q25 - 1.5 * IQR
  # upper bound
  upper_bound = q75 + 1.5 * IQR
  # outliers
  outlier_ind <- which(x < lower_bound | x > upper_bound)
  if (length(outlier_ind) == 0){
    return (0)
  }
  return(outlier_ind)
}
par(mfrow=c(1,1))
boxplot(data[,c(1,2,3,4,5,6,7,8)])
apply(data[,c(1,2,3,4,5,6,7,8)],2,outliers)
data = data[-c(7,8,9,14,26,27,28,68,95,96,117,10,12,60,196,300,301,327,395,323),]
#Multicollinearity check
library(car)
car::vif(lm(data$mpg ~ ., data = data))
#Thong ke mo ta
summary(data)
pastecs::stat.desc(data)
unique(data$model_year)
unique(data$origin)
unique(data$cylinders)
hist(data$mpg,main="Distribution of Mpg", xlab="Mpg" ,col="red")
par(mfrow=c(1,1))
corrplot::corrplot(cor(data[,c(1,2,3,4,5,6,7,8)]), method="number")
ggplot(data,aes(weight,mpg)) +geom_point()+geom_smooth(method=lm)
ggplot(data,aes(cylinders,mpg)) +geom_point()+geom_smooth(method=lm)
ggplot(data,aes(displacement,mpg)) +geom_point()+ geom_smooth(method=lm)
ggplot(data,aes(weight, displacement)) + geom_point(color="red") + geom_smooth(method = lm)
ggplot(data, aes(model_year,mpg,grouping()))+geom_smooth()
ggplot(data, aes(model_year,horsepower,grouping()))+geom_smooth()
#Chia train va validation data, factor data
data$model_year = factor(data$model_year,labels = sort(unique(data$model_year)))
data$origin = factor(data$origin,labels = sort(unique(data$origin)))
data$cylinders = factor(data$cylinders,labels = sort(unique(data$cylinders)))
set.seed(190)
index <- sample(nrow(data), 200,replace = FALSE)
auto_mpg1 = data[index,]
dim(auto_mpg1)
auto_mpg2 = data[-index,]
dim(auto_mpg2)
dim(data)
#Chon mo hinh
model_All <- lm(mpg ~. - car_name, data = auto_mpg1)
summary(model_All)
#stepwise theo tieu chuan BIC
n = nrow(auto_mpg1)
modbest_bw <- step(model_All, direction = 'backward', k = log(n))
summary(modbest_bw)
#independent_check
lag.plot(modbest_bw$residuals)
car::durbinWatsonTest(modbest_bw)
#stability_check
library(lmtest)
bptest(modbest_bw)
#normal_check
shapiro.test(modbest_bw$residuals)
#prediction
predict_mpg <- predict(modbest_bw, newdata = auto_mpg2)
head(predict_mpg)
sqrt(mean((predict_mpg - auto_mpg2$mpg)^2))
plot(predict(modbest_bw, newdata = auto_mpg2),                                
     auto_mpg2$mpg,
     xlab = "Predicted Values",
     ylab = "Observed Values")
abline(a = 0,                                        # Add straight line
       b = 1,
       col = "red",
       lwd = 2)

