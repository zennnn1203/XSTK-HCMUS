library(leaps)
library(magrittr) 
library("dplyr") 
library(tidyverse)
library(caret)
library("psych")

#read data
install.packages("readxl")
library(readxl)
setwd("D:/HOC TAP/KHOA HOC DU LIEU/MO HINH HOA THONG KE/BAI TAP VE NHA/TUAN 9")
energy = read_excel("ENB2012_data.xlsx")
dim(energy)
names(energy)
head(energy)
str(energy)
summary(energy)

#missing value
library(VIM)
aggr(energy[1:10],sortComb=TRUE, sortVar=TRUE, only.miss=TRUE)
#Kiem tra tap du lieu co gia tri NA khong?
pacman::p_load(naniar)
anyNA(energy)
is.na(energy)

#outliers
outliers <- function(x){
  # 1st and 3rd quantiles
  q75 = quantile(x, 0.75)
  q25 = quantile(x, 0.25)
  IQR = q75-q25
  # lower bound
  lower_bound = q25 - 1.5 * IQR
  # upper bound
  upper_bound = q75 + 1.5 * IQR
  # outliers
  outlier_ind <- which(x < lower_bound | x > upper_bound)
  if (length(outlier_ind) == 0){
    return (0)
  }
  return(outlier_ind)
}
apply(energy,2,outliers)
par(mfrow=c(1,1))
boxplot(energy)

# visualize
library(corrplot)
par(mfrow=c(1,1))
#Cach 1
corrplot(cor(energy), method="number")
#Cach 2
#corrplot(cor(energy[,-c(2,4)]), method="number")

# Multicollinearity
library("car")

model1_1<-(lm(Y1~X1+X2+X3+X4+X5+X6+X7+X8,data=energy))
summary(model1_1)

vif(lm(Y1~X1+X2+X3+X5+X7,data=energy))
vif(lm(Y1~X1+X3+X5+X7,data=energy))
vif(lm(Y1~X1+X3+X7,data=energy))


model2_1<-(lm(Y2~X1+X2+X3+X4+X5+X6+X7+X8,data=energy))
summary(model2_1)
vif(lm(Y2~X1+X2+X3+X5+X7,data=energy))
vif(lm(Y2~X1+X3+X5+X7,data=energy))
vif(lm(Y2~X1+X3+X7,data=energy))

# Model selection
model1_4<-lm(Y1~X1+X3+X7,data=energy)
summary(model1_4)

model2_4<-lm(Y2~X1+X3+X7,data=energy)
summary(model2_4)

best_mod1<-step(lm(Y1~.,data=energy[,-c(10)]))
summary(best_mod1)
vif(lm(Y1~X1+X2+X3+X5+X7,data=energy))
vif(lm(Y1~X1+X3+X5+X7,data=energy))
vif(lm(Y1~X1+X3+X7,data=energy))

#best_mod11<-step(lm(Y1~.-X2-X4,data=energy[,-c(10)]))

best_mod2<-step(lm(Y2~.,data=energy[,-c(9)]))
summary(best_mod2)

#best_mod22<-step(lm(Y2~.-X2-X4,data=energy[,-c(9)]))

#Kiem dinh & lua chon mo hinh
#independent_check
library(carData)
lag.plot(model1_4$residuals)
durbinWatsonTest(model1_4)
lag.plot(model2_4$residuals)
durbinWatsonTest(model2_4)

#normal_check
shapiro.test(model1_4$residuals)

shapiro.test(model2_4$residuals)

#stability_check
library(lmtest)
bptest(model1_4)
bptest(model2_4)


#Phuong phap de xuat
#Mo hinh Y1
install.packages("rpart")
library(rpart)
# Create decision tree using regression
fit1 <- rpart(Y1~X1+X2+X3+X4+X5+X6+X7+X8, 
             method = "anova", data = energy )
# Plot
plot(fit1, uniform = TRUE,
     main = "MPG Decision Tree using Regression")
text(fit1, use.n = TRUE, cex = .6)
predict(fit1, type = "vector")

#Mo hinh Y2
# Create decision tree using regression
fit2 <- rpart(Y2~X1+X2+X3+X4+X5+X6+X7+X8, 
             method = "anova", data = energy )
# Plot
plot(fit2, uniform = TRUE,
     main = "MPG Decision Tree using Regression")
text(fit2, use.n = TRUE, cex = .6)
predict(fit2, type = "vector")

#Bien doi mot so bien bang ham log10
energy$X2=log10(energy$X2)
energy$X3=log10(energy$X3)
energy$X4=log10(energy$X4)
#Chay lai du lieu tu dau va kiem tra hieu qua cac mo hinh

