library(corrplot)
library(car)
library(leaps)
library(lmtest)
library(factoextra)
library(devtools)
library(ggbiplot)
library(VIM)
library(pastecs)
library(gridExtra)
library(ggpubr)
#a) Data_importation
setwd("C:/Users/tuanvl/Desktop/ThS/FinalProject")
Gradu=read.csv("Graduate.csv",header=TRUE)
str(Gradu)
head(Gradu)
#-------------------------------------------------------------------
#b) Data_cleaning
#b1) Missing_values
aggr(Gradu[1:11],sortComb=TRUE, sortVar=FALSE, only.miss=TRUE)
Gradu$Sub2[which(is.na(Gradu$Sub2))]=median.default(Gradu$Sub2,na.rm=TRUE)
Gradu$Sub3[which(is.na(Gradu$Sub3))]=median.default(Gradu$Sub3,na.rm=TRUE)
duplicated(Gradu) #duplicated data
#b2) Remove_Outliers
#outliers_function
outliers <- function(x){
  # 1st and 3rd quantiles
  q75 = quantile(x, 0.75)
  q25 = quantile(x, 0.25)
  IQR = q75-q25
  # lower bound
  lower_bound = q25 - 3 * IQR
  # upper bound
  upper_bound = q75 + 3 * IQR
  # outliers
  outlier_ind <- which(x < lower_bound | x > upper_bound)
  if (length(outlier_ind) == 0){
    return (0)
  }
  return(outlier_ind)
}
par(mfrow=c(1,1))
boxplot(Gradu$Literature,Gradu$Math,Gradu$Sub1,Gradu$Sub2,Gradu$Sub3,Gradu$GPA12,xlab="Subject")
apply(Gradu[,-c(2,9,11)],2,outliers) #Check outliers
#-------------------------------------------------------------------
#c) Data_visualization
Gra=mutate(Gradu,Graduated_score=0.3*(GPA12)+0.175*((Literature+Math+(Sub1+Sub2+Sub3)/3+English+Vocation)))
stat.desc(Gra[,-c(1)]) #descriptive_statistics
par(mfrow=c(1,3))
plot(density(Gra$Math),main="Density of Math")
plot(density(Gra$Literature),main="Density of Literature")
plot(density(Gra$English),main="Density of English")
#descriptive_statistics with graph
par(mfrow=c(1,2))

barplot(table(Gra$Group), main="Frequency of Group")
barplot(table(Gra$IELTS),main="Frequency of IELTS")

means1 <- aggregate(Graduated_score ~  Group, data=Gra, mean)
boxplot(Graduated_score ~  Group, data=Gra)
points(1:2, means1$Graduated_score,col = "red", pch=18)

means2 <- aggregate(Graduated_score ~  IELTS, data=Gra, mean)
boxplot(Graduated_score ~ IELTS, data=Gra)
points(1:2, means2$Graduated_score,col = "red", pch=18)

#-------------------------------------------------------------------
#d) ANOVA
Graduated_score=Gra$Graduated_score
Group=factor(Gra$Group)
IELTS=factor(Gra$IELTS)
av_int=aov(Graduated_score~Group*IELTS)
summary(av_int)
av_add=aov(Graduated_score~Group+IELTS)
summary(av_add)
av_group=aov(Graduated_score~Group)
summary(av_group)
av_IELTS=aov(Graduated_score~IELTS)
summary(av_IELTS)
av_null=aov(Graduated_score~1)
summary(av_null)

par(mfrow=c(1,1))
TukeyHSD(av_IELTS)
plot(TukeyHSD(av_IELTS),las=2)

#normality_assumption
ggqqplot(av_IELTS$residuals)
shapiro.test(av_IELTS$residuals) 
#equality of variances
plot(av_IELTS,1)
leveneTest(Graduated_score~IELTS)
